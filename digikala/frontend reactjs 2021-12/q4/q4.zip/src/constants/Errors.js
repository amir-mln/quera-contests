const ErrorTexts = {
  Required: "این فیلد اجباری است",
};

export default ErrorTexts;
