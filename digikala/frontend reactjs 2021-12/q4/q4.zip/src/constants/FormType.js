const FormType = {
  TEXT: "text",
  DROPDOWN: "dropdown",
  TEXTAREA: "textarea",
  CHECKBOX: "checkbox",
  CITY: "city",
};

export default FormType;
