import React from "react";

function EmptyList() {
  return <p data-testid="empty-list">No Comments</p>;
}

export default EmptyList;
