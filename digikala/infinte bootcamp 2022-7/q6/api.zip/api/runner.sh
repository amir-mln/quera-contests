#!/bin/sh

# Enter commands to run your application
npm run start
