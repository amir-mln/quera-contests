-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2022 at 11:17 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `q4`
--

-- --------------------------------------------------------

--
-- Table structure for table `deliveries`
--

CREATE TABLE `deliveries` (
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `delivery_center_id` bigint(20) UNSIGNED NOT NULL,
  `received_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `delivered_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `deliveries`
--

INSERT INTO `deliveries` (`order_id`, `delivery_center_id`, `received_at`, `delivered_at`) VALUES
(1, 3, '2022-07-14 00:47:19', NULL),
(2, 2, '2022-07-13 12:47:19', '2022-07-13 14:44:21'),
(3, 7, '2022-07-12 18:47:19', '2022-07-12 20:01:47'),
(4, 8, '2022-07-13 06:47:19', '2022-07-13 08:02:59'),
(5, 3, '2022-07-14 06:47:19', NULL),
(6, 1, '2022-07-13 00:47:19', NULL),
(7, 1, '2022-07-14 12:47:19', '2022-07-14 14:21:20'),
(8, 7, '2022-07-13 18:47:19', '2022-07-13 20:32:01'),
(9, 1, '2022-07-12 12:47:19', NULL),
(10, 5, '2022-07-12 06:47:19', '2022-07-12 08:45:12');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_centers`
--

CREATE TABLE `delivery_centers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `delivery_centers`
--

INSERT INTO `delivery_centers` (`id`, `name`) VALUES
(1, 'qui aperiam'),
(2, 'nulla excepturi'),
(3, 'provident natus'),
(4, 'aspernatur omnis'),
(5, 'id error'),
(6, 'numquam voluptatum'),
(7, 'laudantium temporibus'),
(8, 'labore quod'),
(9, 'et asperiores'),
(10, 'laudantium aspernatur');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `created_at`) VALUES
(1, 217003, '2022-07-09 18:47:19'),
(2, 732493, '2022-07-10 06:47:19'),
(3, 269127, '2022-07-10 18:47:19'),
(4, 47245, '2022-07-11 06:47:19'),
(5, 207792, '2022-07-11 18:47:19'),
(6, 456178, '2022-07-12 06:47:19'),
(7, 875098, '2022-07-12 18:47:19'),
(8, 353625, '2022-07-13 06:47:19'),
(9, 258266, '2022-07-13 18:47:19'),
(10, 474065, '2022-07-14 06:47:19');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`id`, `order_id`, `product_id`, `quantity`) VALUES
(1, 2, 4, 8),
(2, 10, 49, 3),
(3, 6, 12, 8),
(4, 8, 3, 9),
(5, 9, 75, 7),
(6, 5, 4, 10),
(7, 7, 100, 7),
(8, 2, 63, 1),
(9, 1, 21, 2),
(10, 1, 79, 9),
(11, 4, 10, 6),
(12, 5, 58, 8),
(13, 5, 66, 5),
(14, 10, 84, 5),
(15, 1, 7, 5),
(16, 10, 77, 3),
(17, 2, 43, 8),
(18, 9, 54, 7),
(19, 2, 81, 8),
(20, 5, 93, 8),
(21, 8, 11, 1),
(22, 5, 1, 9),
(23, 7, 30, 6),
(24, 9, 28, 7),
(25, 5, 24, 7),
(26, 10, 72, 9),
(27, 4, 24, 2),
(28, 10, 100, 9),
(29, 5, 89, 8),
(30, 9, 20, 8);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(15,2) NOT NULL,
  `total_profit` decimal(15,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `description`, `price`, `total_profit`, `created_at`) VALUES
(1, 'consequatur dolores dolorum', 'Amet iste.', '10899010.00', '0.00', '2022-04-05 18:47:19'),
(2, 'est dolor dolores', 'Minus.', '36014000.00', '0.00', '2022-04-06 18:47:19'),
(3, 'quibusdam sed vel', 'A quo sed.', '32255000.00', '0.00', '2022-04-07 18:47:19'),
(4, 'perferendis dolores molestias', 'Ipsam sit.', '10182000.00', '0.00', '2022-04-08 18:47:19'),
(5, 'fuga aspernatur natus', 'Earum quas.', '737000.00', '0.00', '2022-04-09 18:47:19'),
(6, 'voluptatibus incidunt nostrum', 'Quia possimus.', '36728000.00', '0.00', '2022-04-10 18:47:19'),
(7, 'et necessitatibus architecto', 'Aut.', '43860000.00', '0.00', '2022-04-11 18:47:19'),
(8, 'et id nisi', 'Qui id totam.', '10380000.00', '0.00', '2022-04-12 18:47:19'),
(9, 'ipsam ut iusto', 'Iusto.', '21780000.00', '0.00', '2022-04-13 18:47:19'),
(10, 'similique accusantium et', 'A qui ducimus.', '23156000.00', '0.00', '2022-04-14 18:47:19'),
(11, 'nihil autem omnis', 'Cum molestiae.', '28080000.00', '0.00', '2022-04-15 18:47:19'),
(12, 'ex dicta hic', 'Inventore.', '40972000.00', '0.00', '2022-04-16 18:47:19'),
(13, 'est quae non', 'Quia dicta in.', '26689090.00', '0.00', '2022-04-17 18:47:19'),
(14, 'qui a voluptatem', 'Dignissimos.', '16517000.00', '0.00', '2022-04-18 18:47:19'),
(15, 'labore quos ea', 'Rerum.', '30379000.00', '0.00', '2022-04-19 18:47:19'),
(16, 'nostrum et voluptas', 'Consequatur.', '18884000.00', '0.00', '2022-04-20 18:47:19'),
(17, 'nam sunt provident', 'Quia et.', '31158000.00', '0.00', '2022-04-21 18:47:19'),
(18, 'a debitis autem', 'Eveniet quis.', '19060000.00', '0.00', '2022-04-22 18:47:19'),
(19, 'autem deleniti ut', 'Quibusdam et.', '39332000.00', '0.00', '2022-04-23 18:47:19'),
(20, 'illo dolorum omnis', 'Repellendus.', '35223000.00', '0.00', '2022-04-24 18:47:19'),
(21, 'aut nisi officiis', 'Rerum id.', '20499000.00', '0.00', '2022-04-25 18:47:19'),
(22, 'sit rem quia', 'Odit aut.', '3623000.00', '0.00', '2022-04-26 18:47:19'),
(23, 'ut qui culpa', 'Reiciendis.', '34517000.00', '0.00', '2022-04-27 18:47:19'),
(24, 'consequatur doloribus optio', 'Est similique.', '19197000.00', '0.00', '2022-04-28 18:47:19'),
(25, 'qui sint laudantium', 'Fuga dolorem.', '7982000.00', '0.00', '2022-04-29 18:47:19'),
(26, 'voluptatem itaque magnam', 'Quis dolorem.', '31705000.00', '0.00', '2022-04-30 18:47:19'),
(27, 'aut iste animi', 'Pariatur.', '28442000.00', '0.00', '2022-05-01 18:47:19'),
(28, 'officiis non velit', 'Ab accusantium.', '21673000.00', '0.00', '2022-05-02 18:47:19'),
(29, 'quas numquam sed', 'Ut sit numquam.', '8919000.00', '0.00', '2022-05-03 18:47:19'),
(30, 'suscipit molestiae incidunt', 'Aut impedit a.', '45872000.00', '0.00', '2022-05-04 18:47:19'),
(31, 'iste nesciunt delectus', 'Inventore.', '38170000.00', '0.00', '2022-05-05 18:47:19'),
(32, 'doloremque illo deserunt', 'Placeat fugit.', '47543000.00', '0.00', '2022-05-06 18:47:19'),
(33, 'sequi soluta nesciunt', 'Consequatur.', '22918000.00', '0.00', '2022-05-07 18:47:19'),
(34, 'consequatur vitae et', 'Debitis iure.', '15195000.00', '0.00', '2022-05-08 18:47:19'),
(35, 'ut quas sit', 'Quo explicabo.', '35341000.00', '0.00', '2022-05-09 18:47:19'),
(36, 'dolorem est quod', 'Aspernatur.', '38970000.00', '0.00', '2022-05-10 18:47:19'),
(37, 'sint animi harum', 'Nihil.', '7612000.00', '0.00', '2022-05-11 18:47:19'),
(38, 'quam suscipit ut', 'Laboriosam.', '46160000.00', '0.00', '2022-05-12 18:47:19'),
(39, 'sunt itaque culpa', 'Tempore quis.', '11057000.00', '0.00', '2022-05-13 18:47:19'),
(40, 'qui vel porro', 'Occaecati quia.', '43141000.00', '0.00', '2022-05-14 18:47:19'),
(41, 'incidunt alias accusantium', 'Dolorem est.', '43825000.00', '0.00', '2022-05-15 18:47:19'),
(42, 'iusto quia doloribus', 'Molestiae.', '32906000.00', '0.00', '2022-05-16 18:47:19'),
(43, 'sit error iste', 'Similique sint.', '33543000.00', '0.00', '2022-05-17 18:47:19'),
(44, 'consequatur enim ab', 'Qui et omnis.', '36624000.00', '0.00', '2022-05-18 18:47:19'),
(45, 'quae doloremque dolorum', 'Libero nam.', '13083000.00', '0.00', '2022-05-19 18:47:19'),
(46, 'saepe sit omnis', 'Vel dolor.', '38092000.00', '0.00', '2022-05-20 18:47:19'),
(47, 'doloribus beatae laboriosam', 'Expedita.', '21726000.00', '0.00', '2022-05-21 18:47:19'),
(48, 'sed sed et', 'Optio.', '47613000.00', '0.00', '2022-05-22 18:47:19'),
(49, 'deleniti necessitatibus animi', 'Alias itaque.', '2307000.00', '0.00', '2022-05-23 18:47:19'),
(50, 'blanditiis et omnis', 'Maiores fugit.', '1550000.00', '0.00', '2022-05-24 18:47:19'),
(51, 'repellat deserunt nihil', 'Quidem commodi.', '18976000.00', '0.00', '2022-05-25 18:47:19'),
(52, 'accusamus quam temporibus', 'Doloribus.', '29567000.00', '0.00', '2022-05-26 18:47:19'),
(53, 'consequatur eius et', 'Rem numquam.', '35083000.00', '0.00', '2022-05-27 18:47:19'),
(54, 'deleniti fuga quas', 'Quos et neque.', '14266000.00', '0.00', '2022-05-28 18:47:19'),
(55, 'nihil natus quasi', 'Aut unde harum.', '36550000.00', '0.00', '2022-05-29 18:47:19'),
(56, 'aliquid voluptatum ab', 'Nisi dolor.', '45246000.00', '0.00', '2022-05-30 18:47:19'),
(57, 'consequuntur non fugiat', 'Possimus id.', '43381000.00', '0.00', '2022-05-31 18:47:19'),
(58, 'mollitia quis et', 'Reprehenderit.', '44722000.00', '0.00', '2022-06-01 18:47:19'),
(59, 'rem et omnis', 'Rerum.', '871000.00', '0.00', '2022-06-02 18:47:19'),
(60, 'aperiam quia inventore', 'Consequatur ea.', '27414000.00', '0.00', '2022-06-03 18:47:19'),
(61, 'est dolor porro', 'Sunt ipsa sed.', '31822000.00', '0.00', '2022-06-04 18:47:19'),
(62, 'veniam molestiae libero', 'Ipsum vitae.', '11818000.00', '0.00', '2022-06-05 18:47:19'),
(63, 'accusamus molestias sed', 'Distinctio.', '31534000.00', '0.00', '2022-06-06 18:47:19'),
(64, 'qui et delectus', 'Unde ipsum.', '9492000.00', '0.00', '2022-06-07 18:47:19'),
(65, 'deleniti aut voluptatibus', 'Dicta quis.', '669000.00', '0.00', '2022-06-08 18:47:19'),
(66, 'explicabo et similique', 'Officiis sint.', '11274000.00', '0.00', '2022-06-09 18:47:19'),
(67, 'autem exercitationem facilis', 'Quas.', '24939000.00', '0.00', '2022-06-10 18:47:19'),
(68, 'modi maxime quam', 'Debitis.', '11092000.00', '0.00', '2022-06-11 18:47:19'),
(69, 'et porro magnam', 'Alias.', '43087000.00', '0.00', '2022-06-12 18:47:19'),
(70, 'autem eveniet exercitationem', 'Consequatur.', '28296000.00', '0.00', '2022-06-13 18:47:19'),
(71, 'eum voluptate ut', 'Delectus.', '41766000.00', '0.00', '2022-06-14 18:47:19'),
(72, 'alias et tenetur', 'Dolor at in.', '10329000.00', '0.00', '2022-06-15 18:47:19'),
(73, 'odit iure optio', 'Reiciendis.', '38828000.00', '0.00', '2022-06-16 18:47:19'),
(74, 'vel voluptates voluptatem', 'Aut at porro.', '31325000.00', '0.00', '2022-06-17 18:47:19'),
(75, 'ut repellat error', 'Deleniti.', '8678000.00', '0.00', '2022-06-18 18:47:19'),
(76, 'error pariatur suscipit', 'Nobis vel.', '39881000.00', '0.00', '2022-06-19 18:47:19'),
(77, 'illo eum sint', 'Iste sit et.', '15902000.00', '0.00', '2022-06-20 18:47:19'),
(78, 'exercitationem labore eaque', 'Numquam.', '7432000.00', '0.00', '2022-06-21 18:47:19'),
(79, 'quis ut nisi', 'Eligendi at.', '6832000.00', '0.00', '2022-06-22 18:47:19'),
(80, 'ratione iste nam', 'Sit tempore ut.', '34196000.00', '0.00', '2022-06-23 18:47:19'),
(81, 'est inventore aut', 'Praesentium in.', '7706000.00', '0.00', '2022-06-24 18:47:19'),
(82, 'corrupti ab corporis', 'Nobis qui non.', '20533000.00', '0.00', '2022-06-25 18:47:19'),
(83, 'dolor ipsa praesentium', 'Qui numquam.', '29698000.00', '0.00', '2022-06-26 18:47:19'),
(84, 'quia eveniet iusto', 'Aut corrupti.', '6484000.00', '0.00', '2022-06-27 18:47:19'),
(85, 'qui quisquam perferendis', 'Aut ex est cum.', '8218000.00', '0.00', '2022-06-28 18:47:19'),
(86, 'cumque numquam explicabo', 'Necessitatibus.', '3829000.00', '0.00', '2022-06-29 18:47:19'),
(87, 'rerum rem libero', 'Sunt in.', '8817000.00', '0.00', '2022-06-30 18:47:19'),
(88, 'sed consequatur expedita', 'Debitis.', '35897000.00', '0.00', '2022-07-01 18:47:19'),
(89, 'et consequatur aliquid', 'Error ipsum.', '32424000.00', '0.00', '2022-07-02 18:47:19'),
(90, 'rem quidem velit', 'Eius fugiat.', '24799000.00', '0.00', '2022-07-03 18:47:19'),
(91, 'doloribus perferendis aut', 'Id voluptas.', '11403000.00', '0.00', '2022-07-04 18:47:19'),
(92, 'dolorem ea expedita', 'Quos sunt.', '21382000.00', '0.00', '2022-07-05 18:47:19'),
(93, 'quaerat ab possimus', 'Veniam magni.', '36885000.00', '0.00', '2022-07-06 18:47:19'),
(94, 'animi dolor ut', 'Vero saepe.', '6986000.00', '0.00', '2022-07-07 18:47:19'),
(95, 'suscipit a sunt', 'Ab quia.', '36188000.00', '0.00', '2022-07-08 18:47:19'),
(96, 'praesentium quas unde', 'Beatae saepe.', '47184000.00', '0.00', '2022-07-09 18:47:19'),
(97, 'et consectetur sed', 'Quis ea.', '657000.00', '0.00', '2022-07-10 18:47:19'),
(98, 'et excepturi repellat', 'Enim qui fuga.', '38764000.00', '0.00', '2022-07-11 18:47:19'),
(99, 'sint quasi dolores', 'Sunt ea ut.', '26697000.00', '0.00', '2022-07-01 18:47:20'),
(100, 'autem ipsa nisi', 'Enim ut vitae.', '14383000.00', '0.00', '2022-07-12 17:47:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deliveries`
--
ALTER TABLE `deliveries`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `delivery_centers`
--
ALTER TABLE `delivery_centers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `delivery_centers`
--
ALTER TABLE `delivery_centers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `order_details`
--
ALTER TABLE `order_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
